import org.json.JSONObject;
import org.testng.annotations.BeforeMethod;

import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class BaseTest {
    protected RequestSpecification spec;

    protected String getStatusMessageText(Response response) {
        String statusMessageText=new String();
        String[] statusMessage= response.statusLine().split(" ");
        for(int i = 2; i < statusMessage.length; i++){
            if(i>2) statusMessageText+=" ";
            statusMessageText+=statusMessage[i];
        }
        return statusMessageText;
    }

    @BeforeMethod
    public void setUp() {
        spec = new RequestSpecBuilder().
                setBaseUri("https://restful-booker.herokuapp.com").
                build();
    }

}