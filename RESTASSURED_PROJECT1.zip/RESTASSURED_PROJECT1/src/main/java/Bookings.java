import java.util.ArrayList;
import java.util.List;

public class Bookings {
    private final List<Booking> bookingList;

    Bookings(){
        this.bookingList=new ArrayList<>();
    }
    public List<Booking> getAllBookings(){
        BookingDates bookingdates1 = new BookingDates("2024-03-05", "2024-03-06");
        Booking booking1 = new Booking("John", "Doe", 200, false, bookingdates1, "lunch");
        bookingList.add(booking1);

        BookingDates bookingdates2 = new BookingDates("2024-03-06", "2024-03-08");
        Booking booking2 = new Booking("Alice", "Smith", 300, true, bookingdates2, "dinner");
        bookingList.add(booking2);

        BookingDates bookingdates3 = new BookingDates("2024-03-09", "2024-03-11");
        Booking booking3 = new Booking("Bob", "Johnson", 150, false, bookingdates3, "breakfast");
        bookingList.add(booking3);

        BookingDates bookingdates4 = new BookingDates("2024-03-12", "2024-03-15");
        Booking booking4 = new Booking("Emily", "Brown", 250, true, bookingdates4, "lunch");
        bookingList.add(booking4);

        BookingDates bookingdates5 = new BookingDates("2024-03-16", "2024-03-18");
        Booking booking5 = new Booking("Michael", "Wilson", 180, false, bookingdates5, "dinner");
        bookingList.add(booking5);

        BookingDates bookingdates6 = new BookingDates("2024-03-19", "2024-03-21");
        Booking booking6 = new Booking("Sophia", "Martinez", 220, true, bookingdates6, "breakfast");
        bookingList.add(booking6);

        BookingDates bookingdates7 = new BookingDates("2024-03-22", "2024-03-25");
        Booking booking7 = new Booking("David", "Taylor", 190, false, bookingdates7, "lunch");
        bookingList.add(booking7);

        BookingDates bookingdates8 = new BookingDates("2024-03-26", "2024-03-28");
        Booking booking8 = new Booking("Emma", "Anderson", 280, true, bookingdates8, "dinner");
        bookingList.add(booking8);

        BookingDates bookingdates9 = new BookingDates("2024-03-29", "2024-04-01");
        Booking booking9 = new Booking("James", "Thomas", 170, false, bookingdates9, "breakfast");
        bookingList.add(booking9);

        BookingDates bookingdates10 = new BookingDates("2024-04-02", "2024-04-05");
        Booking booking10 = new Booking("Olivia", "Harris", 300, true, bookingdates10, "lunch");
        bookingList.add(booking10);

        return bookingList;
    }

    public List<Booking> getUpdatedBookingList() {
        List<Booking> updatedList=new ArrayList<>();

        BookingDates bookingdates1 = new BookingDates("2024-03-08", "2024-03-09");
        Booking booking1 = new Booking("John", "Doe", 200, false, bookingdates1, "lunch");
        updatedList.add(booking1);

        BookingDates bookingdates2 = new BookingDates("2024-03-06", "2024-03-08");
        Booking booking2 = new Booking("Alice", "Smith", 300, false, bookingdates2, "dinner");
        updatedList.add(booking2);

        BookingDates bookingdates3 = new BookingDates("2024-03-09", "2024-03-11");
        Booking booking3 = new Booking("Bob", "Jobs", 150, false, bookingdates3, "breakfast");
        updatedList.add(booking3);

        BookingDates bookingdates4 = new BookingDates("2024-03-12", "2024-03-15");
        Booking booking4 = new Booking("Emily", "Brown", 150, true, bookingdates4, "lunch");
        updatedList.add(booking4);

        BookingDates bookingdates5 = new BookingDates("2024-03-16", "2024-03-20");
        Booking booking5 = new Booking("Michael", "Wilson", 130, false, bookingdates5, "dinner");
        updatedList.add(booking5);

        BookingDates bookingdates6 = new BookingDates("2024-03-19", "2024-03-21");
        Booking booking6 = new Booking("Sophia", "Martinez", 520, false, bookingdates6, "breakfast");
        updatedList.add(booking6);

        BookingDates bookingdates7 = new BookingDates("2024-03-22", "2024-03-25");
        Booking booking7 = new Booking("David", "Taylor", 3000, false, bookingdates7, "lunch");
        updatedList.add(booking7);

        BookingDates bookingdates8 = new BookingDates("2024-03-26", "2024-03-28");
        Booking booking8 = new Booking("Emma", "Anderson", 8000, true, bookingdates8, "dinner");
        updatedList.add(booking8);

        BookingDates bookingdates9 = new BookingDates("2024-03-29", "2024-04-01");
        Booking booking9 = new Booking("James", "Tom", 170, false, bookingdates9, "breakfast");
        updatedList.add(booking9);

        BookingDates bookingdates10 = new BookingDates("2024-04-03", "2024-04-05");
        Booking booking10 = new Booking("Olivia", "Harry", 300, true, bookingdates10, "baby care");
        updatedList.add(booking10);

        return updatedList;
    }
}
