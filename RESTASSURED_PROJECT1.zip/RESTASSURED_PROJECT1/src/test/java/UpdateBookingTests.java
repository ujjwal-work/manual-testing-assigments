import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.List;

public class UpdateBookingTests extends BaseTest{
    @Test
    public void updateBooking_normal() {
        Bookings bookings=new Bookings();
        Booking booking=bookings.getAllBookings().get(0);
        Booking updated=bookings.getUpdatedBookingList().get(0);

        Response responseCreate = RestAssured.given(spec).contentType(ContentType.JSON).body(booking)
                .post("/booking");
        BookingId bookingid = responseCreate.as(BookingId.class);

        Response response = RestAssured.given(spec).auth().preemptive().basic("admin", "password123").contentType(ContentType.JSON).body(updated)
                .put("/booking/"+bookingid.getBookingid());
        Booking responseBody=response.as(Booking.class);

        Assert.assertEquals(response.getStatusCode(),200,"status code 200 was expected");
        Assert.assertEquals(responseBody.toString(),updated.toString(),"response body mismatch");
    }

    @Test
    public void updateBooking_noAuth() {
        Bookings bookings=new Bookings();
        Booking booking=bookings.getAllBookings().get(0);
        Booking updated=bookings.getUpdatedBookingList().get(0);

        Response responseCreate = RestAssured.given(spec).contentType(ContentType.JSON).body(booking)
                .post("/booking");
        BookingId bookingid = responseCreate.as(BookingId.class);

        Response response = RestAssured.given(spec).contentType(ContentType.JSON).body(updated)
                .put("/booking/"+bookingid.getBookingid());

        Assert.assertEquals(response.getStatusCode(),403,"status code 403 was expected");
        Assert.assertEquals(getStatusMessageText(response),"Forbidden","response body mismatch");
    }

    @Test
    public void updateBooking_idNotExist() {
        Bookings bookings=new Bookings();
        Booking booking=bookings.getAllBookings().get(0);

        Response response = RestAssured.given(spec).auth().preemptive().basic("admin", "password123").contentType(ContentType.JSON).body(booking)
                .put("/booking/15000000000000000");

        Assert.assertEquals(response.getStatusCode(),404,"status code 404 was expected");
        Assert.assertEquals(getStatusMessageText(response),"Not Found","response body mismatch");
    }

    @Test
    public void updateBooking_missingFields() {
        Bookings bookings=new Bookings();
        Booking booking=bookings.getAllBookings().get(0);
        Response responseCreate = RestAssured.given(spec).contentType(ContentType.JSON).body(booking)
                .post("/booking");
        BookingId bookingid = responseCreate.as(BookingId.class);

        JSONObject body = new JSONObject();
        body.put("firstname", "Dmitry");
        body.put("lastname", "Shyshkin");
//        body.put("totalprice", 150);
        body.put("depositpaid", false);

        JSONObject bookingdates = new JSONObject();
        bookingdates.put("checkin", "2020-03-25");
        bookingdates.put("checkout", "2020-03-27");
        body.put("bookingdates", bookingdates);
        body.put("additionalneeds", "Baby crib");

        Response response = RestAssured.given(spec).auth().preemptive().basic("admin", "password123").contentType(ContentType.JSON).body(body.toString())
                .put("/booking/"+bookingid.getBookingid());

        Assert.assertEquals(response.getStatusCode(),400,"status code 404 was expected");
        Assert.assertEquals(getStatusMessageText(response),"Bad Request","response body mismatch");
    }
}
