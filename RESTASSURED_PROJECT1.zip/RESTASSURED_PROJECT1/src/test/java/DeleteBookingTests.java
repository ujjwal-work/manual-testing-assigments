import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.Test;

public class DeleteBookingTests extends BaseTest{
    @Test
    public void deleteBooking_normal() {
        Bookings bookings=new Bookings();
        Booking booking=bookings.getAllBookings().get(0);
        Booking updated=bookings.getUpdatedBookingList().get(0);

        Response responseCreate = RestAssured.given(spec).contentType(ContentType.JSON).body(booking)
                .post("/booking");
        BookingId bookingid = responseCreate.as(BookingId.class);

        Response response = RestAssured.given(spec).auth().preemptive().basic("admin", "password123").contentType(ContentType.JSON).body(updated)
                .delete("/booking/"+bookingid.getBookingid());

        Assert.assertEquals(response.getStatusCode(),201,"status code 201 was expected");
    }

    @Test
    public void deleteBooking_noAuth() {
        Bookings bookings=new Bookings();
        Booking booking=bookings.getAllBookings().get(0);
        Booking updated=bookings.getUpdatedBookingList().get(0);

        Response responseCreate = RestAssured.given(spec).contentType(ContentType.JSON).body(booking)
                .post("/booking");
        BookingId bookingid = responseCreate.as(BookingId.class);

        Response response = RestAssured.given(spec).contentType(ContentType.JSON).body(updated)
                .delete("/booking/"+bookingid.getBookingid());

        Assert.assertEquals(response.getStatusCode(),403,"status code 403 was expected");
        Assert.assertEquals(getStatusMessageText(response),"Forbidden","response body mismatch");
    }

    @Test
    public void updateBooking_idNotExist() {
        Bookings bookings=new Bookings();
        Booking booking=bookings.getAllBookings().get(0);

        Response response = RestAssured.given(spec).auth().preemptive().basic("admin", "password123").contentType(ContentType.JSON).body(booking)
                .delete("/booking/15000000000000000");

        Assert.assertEquals(response.getStatusCode(),404,"status code 404 was expected");
        Assert.assertEquals(getStatusMessageText(response),"Not Found","response body mismatch");
    }
}
