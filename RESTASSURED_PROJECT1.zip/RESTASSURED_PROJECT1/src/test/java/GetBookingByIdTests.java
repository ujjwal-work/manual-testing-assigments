import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.List;

public class GetBookingByIdTests extends BaseTest{
    @Test
    public void getBookingById_normal() {
        Bookings bookings=new Bookings();
        List<Booking> bookingList=bookings.getAllBookings();
        Response responseCreate = RestAssured.given(spec).contentType(ContentType.JSON).body(bookingList.get(0))
                .post("/booking");
        BookingId bookingid = responseCreate.as(BookingId.class);

        Response response = RestAssured.given(spec).contentType(ContentType.JSON)
                .get("/booking/"+bookingid.getBookingid());
        Booking responseBody=response.as(Booking.class);

        Assert.assertEquals(response.getStatusCode(),200,"status code 200 was expected");
        Assert.assertEquals(responseBody.toString(),bookingid.getBooking().toString(),"response body mismatch");

    }

    @Test
    public void getBookingById_BookingNotExist() {
        Response response = RestAssured.given(spec).contentType(ContentType.JSON)
                .get("/booking/1500000000000");

        String statusMessageText = getStatusMessageText(response);
        Assert.assertEquals(response.getStatusCode(),404,"status code 404 was expected");
        Assert.assertEquals(statusMessageText,"Not Found","response body mismatch");

    }

}
