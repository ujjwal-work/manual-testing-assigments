import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.List;

public class BookingTests extends BaseTest {


    @Test
    public void createBookingTest() {
        Bookings bookings=new Bookings();
        List<Booking> bookingList=bookings.getAllBookings();
        createBooking(bookingList);
    }

    @Test
    public void createBookingTestWithMissingField(){
        JSONObject body = new JSONObject();
        body.put("firstname", "Dmitry");
        body.put("lastname", "Shyshkin");
//        body.put("totalprice", 150);
        body.put("depositpaid", false);

        JSONObject bookingdates = new JSONObject();
        bookingdates.put("checkin", "2020-03-25");
        bookingdates.put("checkout", "2020-03-27");
        body.put("bookingdates", bookingdates);
        body.put("additionalneeds", "Baby crib");

        Response response = RestAssured.given(spec).contentType(ContentType.JSON).body(body.toString())
                .post("/booking");
        Assert.assertEquals(response.getStatusCode(), 500, "Status code should be 500, but it's not");
    }

    @Test
    public void updateBookingTest() {
        Bookings bookings=new Bookings();
        List<Booking> bookingList=bookings.getAllBookings();
        List<Booking> updatedList=bookings.getUpdatedBookingList();
        updateBooking(bookingList, updatedList);
    }

    @Test
    public void getBookingTest() {
        Bookings bookings=new Bookings();
        List<Booking> bookingList=bookings.getAllBookings();
        getBooking(bookingList);
    }

    @Test
    public void deleteBookingTest() {
        Bookings bookings=new Bookings();
        List<Booking> bookingList=bookings.getAllBookings();

        deleteBooking(bookingList);
    }


    private void getBooking(List<Booking> bookingList) {
        for(int i=0;i<10;i++){
            Response responseCreate = RestAssured.given(spec).contentType(ContentType.JSON).body(bookingList.get(i))
                    .post("/booking");
            BookingId bookingid = responseCreate.as(BookingId.class);

            Response response =
                    RestAssured.given(spec).contentType(ContentType.JSON)
                    .get("/booking/"+bookingid.getBookingid());

            Booking getResponse=response.as(Booking.class);

            Assert.assertEquals(response.getStatusCode(), 200, "Status code should be 200, but it's not");
            Assert.assertEquals(bookingid.getBooking().toString(), getResponse.toString());
            response.print();
        }
    }

    private void createBooking(List<Booking> bookingList) {
        for(int i=0;i<10;i++){
            Response response = RestAssured.given(spec).contentType(ContentType.JSON).body(bookingList.get(i))
                    .post("/booking");
            BookingId bookingid = response.as(BookingId.class);
            response.print();
            Assert.assertEquals(response.getStatusCode(), 200, "Status code should be 200, but it's not");
            Assert.assertEquals(bookingid.getBooking().toString(), bookingList.get(i).toString());
        }
    }

    private void deleteBooking(List<Booking> bookingList) {
        List<Booking> bookingUpdatedList=new ArrayList<>();
        for(int i=0;i<10;i++){
            Response responseCreate = RestAssured.given(spec).contentType(ContentType.JSON).body(bookingList.get(i))
                    .post("/booking");
            BookingId bookingid = responseCreate.as(BookingId.class);

            Response response = RestAssured.given(spec).auth().preemptive().basic("admin", "password123").contentType(ContentType.JSON)
                    .delete("/booking/"+bookingid.getBookingid());
            String result=response.print();
            Assert.assertEquals(response.getStatusCode(), 201, "Status code should be 200, but it's not");
            Assert.assertEquals(result,"Created");
        }
    }


    private void updateBooking(List<Booking> bookingList, List<Booking> updatedList) {
        int n=bookingList.size();
        for(int i=0;i<n;i++){
            Response responseCreate = RestAssured.given(spec).contentType(ContentType.JSON).body(bookingList.get(i))
                    .post("/booking");
            BookingId bookingid = responseCreate.as(BookingId.class);

            Response response = RestAssured.given(spec).auth().preemptive().basic("admin", "password123").contentType(ContentType.JSON).body(updatedList.get(i))
                    .put("/booking/"+bookingid.getBookingid());
            Booking updatedBooking = response.as(Booking.class);
            response.print();
            Assert.assertEquals(response.getStatusCode(), 200, "Status code should be 200, but it's not");
            Assert.assertEquals(updatedBooking.toString(), updatedList.get(i).toString());
        }
    }
}
