import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.List;

public class CreateBookingTests extends BaseTest {
    @Test
    public void createBooking_normal() {
        Bookings bookings=new Bookings();
        List<Booking> bookingList=bookings.getAllBookings();

        Response response = RestAssured.given(spec).contentType(ContentType.JSON).body(bookingList.get(0))
                .post("/booking");
        BookingId bookingid = response.as(BookingId.class);
        Assert.assertEquals(response.getStatusCode(), 200, "Status code should be 200");
        Assert.assertTrue((bookingid.getBookingid()>0));
        Assert.assertEquals(bookingid.getBooking().toString(), bookingList.get(0).toString());
    }

    @Test
    public void createBooking_missingfeild() {
        JSONObject body = new JSONObject();
        body.put("firstname", "Dmitry");
        body.put("lastname", "Shyshkin");
//        body.put("totalprice", 150);
        body.put("depositpaid", false);

        JSONObject bookingdates = new JSONObject();
        bookingdates.put("checkin", "2020-03-25");
        bookingdates.put("checkout", "2020-03-27");
        body.put("bookingdates", bookingdates);
        body.put("additionalneeds", "Baby crib");

        Response response = RestAssured.given(spec).contentType(ContentType.JSON).body(body.toString())
                .post("/booking");
        Assert.assertEquals(response.getStatusCode(), 400, "Status code should be 400");
        Assert.assertEquals(getStatusMessageText(response), "Bad Request", "Status code should be 500");
    }

    @Test
    public void createBooking_invalidTypes() {

        JSONObject body = new JSONObject();
        body.put("firstname", "Susan");
        body.put("lastname", "Wilson");
        body.put("totalprice", 326);
        body.put("depositpaid", "false");  // invalid type

        JSONObject bookingdates = new JSONObject();
        bookingdates.put("checkin", "nlsandlsadl"); /// invalid type
        bookingdates.put("checkout", "2020-03-27");
        body.put("bookingdates", bookingdates);
        body.put("additionalneeds", "Baby crib");

        Response response = RestAssured.given(spec).contentType(ContentType.JSON).body(body.toString())
                .post("/booking");
        Assert.assertEquals(response.getStatusCode(), 400, "Status code should be 400");
        Assert.assertEquals(getStatusMessageText(response), "Bad Request", "Status code should be 500");
    }

    @Test
    public void createBooking_logicValidation() {

        JSONObject body = new JSONObject();
        body.put("firstname", "Susan");
        body.put("lastname", "Wilson");
        body.put("totalprice", 326);
        body.put("depositpaid", "false");

        JSONObject bookingdates = new JSONObject();
        bookingdates.put("checkin", "2024-05-27"); // checkin date is greater than checout date
        bookingdates.put("checkout", "2020-03-27");
        body.put("bookingdates", bookingdates);
        body.put("additionalneeds", "Baby crib");

        Response response = RestAssured.given(spec).contentType(ContentType.JSON).body(body.toString())
                .post("/booking");
        Assert.assertEquals(response.getStatusCode(), 400, "Status code should be 400");
        Assert.assertEquals(getStatusMessageText(response), "Bad Request", "Status code should be 500");
    }

}
