import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.json.JSONArray;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.List;
import java.util.Objects;

public class GetBookingsTest extends BaseTest{
    @Test
    public void getBookings_normal() {
        Response response = RestAssured.given(spec).contentType(ContentType.JSON)
                .get("/booking");
        Assert.assertEquals(response.getStatusCode(),200,"status code 200 was expected");
    }

    @Test
    public void getBookingByName() {
        Bookings bookings=new Bookings();
        List<Booking> bookingList=bookings.getAllBookings();
        Response responseCreate = RestAssured.given(spec).contentType(ContentType.JSON).body(bookingList.get(0))
                .post("/booking");
        BookingId bookingid = responseCreate.as(BookingId.class);

        Response response = RestAssured.given(spec).contentType(ContentType.JSON)
                .get("/booking?firstname="+bookingid.getBooking().getFirstname()+"&lastname="+bookingid.getBooking().getLastname());

        String responseBody = response.getBody().asString();
        JSONArray jsonArray = new JSONArray(responseBody);
        int desiredBookingId = bookingid.getBookingid();
        boolean bookingIdPresent = false;

            for (int i = 0; i < jsonArray.length(); i++) {
                int bookingId = jsonArray.getJSONObject(i).getInt("bookingid");
                if (bookingId == desiredBookingId) {
                    bookingIdPresent = true;
                    break;
                }
            }
            Assert.assertEquals(response.getStatusCode(),200,"status code 200 was expected");
        Assert.assertTrue(bookingIdPresent,"booking id should be present");

    }
    @Test
    public void getBookingByDate() {
        Bookings bookings=new Bookings();
        List<Booking> bookingList=bookings.getAllBookings();
        Response responseCreate = RestAssured.given(spec).contentType(ContentType.JSON).body(bookingList.get(0))
                .post("/booking");
        BookingId bookingid = responseCreate.as(BookingId.class);

        Response response = RestAssured.given(spec).contentType(ContentType.JSON)
                .get("/booking?checkin="+bookingid.getBooking().getBookingdates().getCheckin()
                        +"&checkout="+bookingid.getBooking().getBookingdates().getCheckout());

        String responseBody = response.getBody().asString();
        JSONArray jsonArray = new JSONArray(responseBody);
        int desiredBookingId = bookingid.getBookingid();
        boolean bookingIdPresent = false;

        for (int i = 0; i < jsonArray.length(); i++) {
            int bookingId = jsonArray.getJSONObject(i).getInt("bookingid");
            if (bookingId == desiredBookingId) {
                bookingIdPresent = true;
                break;
            }
        }
        Assert.assertEquals(response.getStatusCode(),200,"status code 200 was expected");
        Assert.assertTrue(bookingIdPresent,"booking id should be present");

    }

}
