import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.List;

public class BookingTests extends BaseTest {

    @Test
    public void createBooking() {
        Bookings bookings=new Bookings();
        List<Booking> bookingList=bookings.getAllBookings();
        List<BookingId> bookingIdList=new ArrayList<>();
        List<Response> bookingResponseList=new ArrayList<>();

        for(int i=0;i<10;i++){
            Response response = RestAssured.given(spec).contentType(ContentType.JSON).body(bookingList.get(i))
                    .post("/booking");
            BookingId bookingid = response.as(BookingId.class);
            bookingIdList.add(bookingid);
            bookingResponseList.add(response);
        }

        for(int i=0;i<10;i++) {
            Assert.assertEquals(bookingResponseList.get(i).getStatusCode(), 200, "Status code should be 200, but it's not");
            Assert.assertEquals(bookingIdList.get(i).getBooking().toString(), bookingList.get(i).toString());
        }
    }

    @Test
    public void updateBooking() {
        Bookings bookings=new Bookings();
        List<Booking> bookingList=bookings.getAllBookings();
        List<Booking> updatedList=bookings.getUpdatedBookingList();

        List<Booking> bookingUpdatedList=new ArrayList<>();
        List<Response> bookingResponseList=new ArrayList<>();

        for(int i=0;i<10;i++){
            Response responseCreate = RestAssured.given(spec).contentType(ContentType.JSON).body(bookingList.get(i))
                    .post("/booking");
            BookingId bookingid = responseCreate.as(BookingId.class);

            Response response = RestAssured.given(spec).auth().preemptive().basic("admin", "password123").contentType(ContentType.JSON).body(updatedList.get(i))
                    .put("/booking/"+bookingid.getBookingid());
            Booking updatedBooking = response.as(Booking.class);
            bookingUpdatedList.add(updatedBooking);
            bookingResponseList.add(response);
        }

        for(int i=0;i<10;i++) {
            Assert.assertEquals(bookingResponseList.get(i).getStatusCode(), 200, "Status code should be 200, but it's not");
            Assert.assertEquals(bookingUpdatedList.get(i).toString(), updatedList.get(i).toString());
        }
    }

    @Test
    public void deleteBooking() {
        Bookings bookings=new Bookings();
        List<Booking> bookingList=bookings.getAllBookings();

        List<Booking> bookingUpdatedList=new ArrayList<>();
        for(int i=0;i<10;i++){
            Response responseCreate = RestAssured.given(spec).contentType(ContentType.JSON).body(bookingList.get(i))
                    .post("/booking");
            BookingId bookingid = responseCreate.as(BookingId.class);

            Response response = RestAssured.given(spec).auth().preemptive().basic("admin", "password123").contentType(ContentType.JSON)
                    .delete("/booking/"+bookingid.getBookingid());
            String result=response.print();
            Assert.assertEquals(response.getStatusCode(), 201, "Status code should be 200, but it's not");
            Assert.assertEquals(result,"Created");
        }
    }
}
